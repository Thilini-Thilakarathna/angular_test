export class Product {
   id: number;
  
  
  
}
