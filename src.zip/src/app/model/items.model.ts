export class Items {
id:number;
name:string;
description:string;
price:number;
path:string;



}
