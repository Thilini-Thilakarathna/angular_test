import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders, HttpErrorResponse} from '@angular/common/http'
import { Items } from '../model/items.model';
import { ProductItemComponent } from '../components/shopping-cart/product-list/product-item/product-item.component';
import { Product } from '../model/product';
import { Observable, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
import { resolve } from 'url';




@Injectable({
  providedIn: 'root'
})


export class HttpClientService {

  constructor(private httpClient:HttpClient) { }
  product :Product[]=[];
  map= new Map<any,any>();
 

 
getItem(){
 let response;


 this.httpClient.get('http://localhost:8080/ShCartServer/ItemController').subscribe(res => {
  
   response=res;
  this.product=response.any as Product[];

 });
}




}
