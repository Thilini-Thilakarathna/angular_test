import { Component, OnInit } from '@angular/core';


 import { HttpClientService } from 'src/app/service/http-client.service';
import { Items } from 'src/app/model/items.model';
import { Product } from 'src/app/model/product';


@Component({
  selector: 'app-product-item',
  templateUrl: './product-item.component.html',
  styleUrls: ['./product-item.component.scss']
})
export class ProductItemComponent implements OnInit {

Items: object[];


   constructor(private httpClientService: HttpClientService) { }

  ngOnInit() {
    this.httpClientService.getItem();
    // this.httpClientService.getItem().subscribe(response => this.handlesSuccessfulResponse(response));
  }


 
  handlesSuccessfulResponse(response){
 
  }
}
